// Include standard input/output functions
#include <stdio.h>
// Include string manipulation functions
#include <string.h>

// Define constants
#define MAX_COMPANIES 20  // Maximum number of companies that can be stored
#define NAME_LEN 50      // Maximum length of company name
#define PARAM_COUNT 7    // Number of parameters for each company

// Define structure to store company information on each parameter
struct Company {// a short explanation of each parameter is given in the final report
    char name[NAME_LEN];        // Company name 
    double revenue;             // Company revenue: 
    double pe_ratio;           // Price to Earnings ratio
    double net_profit;         // Net profit
    double market_cap;         // Market capitalization
    double debt_to_equity;     // Debt to Equity ratio
    double dividend_yield;     // Dividend yield percentage
    double promoter_holding;   // Promoter holding percentage
};

// Function to print company data in tabular format
void printTable(struct Company companies[], int n) {//companies is an array holding all the data of the companies
    //n is the number of companies
    // Print table header with column names
    printf("\n%-18s %-12s %-10s %-12s %-15s %-14s %-15s %-18s\n",
        "Company", "Revenue", "P/E", "Net Profit", "Market Cap", "Debt/Equity", "DividendYield", "PromoterHolding");
    // Print separator line
    printf("---------------------------------------------------------------------------------------------------------------\n");//spacing is done by adding the maximum spaces in each column's entries and adding all together no.of spaces is calculated  
    // Print each company's data
    for (int i = 0; i < n; i++) {
        printf("%-18s %-12.2lf %-10.2lf %-12.2lf %-15.2lf %-14.2lf %-15.2lf %-18.2lf\n",// '-' is for left aligning
            //point 2 is for accuracy
            companies[i].name,//printing each of the parameters for each company   
            companies[i].revenue,
            companies[i].pe_ratio,
            companies[i].net_profit,
            companies[i].market_cap,
            companies[i].debt_to_equity,
            companies[i].dividend_yield,
            companies[i].promoter_holding
        );
    }
}

// Function to print points table showing how companies score on each parameter
void printPointsTable(struct Company companies[], int n, int points[][PARAM_COUNT]) {
    //points is a 2d array that holds all the points for each company for each parameter
    
    printf("\n%-20s", "Company");
    // Array of parameter names for column headers
    const char* param_names[PARAM_COUNT] = {
        "Revenue", "P/E", "NetProfit", "MarketCap", "Debt/Equity", "DividendYield", "PromoterHold"
    };
    // Print parameter names as column headers
    for (int p = 0; p < PARAM_COUNT; p++) {
        printf("%-15s", param_names[p]);
    }
    printf("%-10s\n", "Total");
    // Print separator line
    printf("--------------------------------------------------------------------------------\n");
    // Print each company's points
    for (int i = 0; i < n; i++) {
        int total = 0;
        printf("%-20s", companies[i].name);
        for (int p = 0; p < PARAM_COUNT; p++) {
            printf("%-15d", points[i][p]);
            total += points[i][p];
        }
        printf("%-10d\n", total);
    }
} // Remove extra closing brace

// Function to print criteria for scoring so the reader can understand what the points on each parameter imply
void printScoringCriteria() {
    printf("\nScoring Criteria (1 point for each):\n");
    printf(" - Highest Revenue\n");
    printf(" - Lowest P/E Ratio\n");
    printf(" - Highest Net Profit\n");
    printf(" - Highest Market Cap\n");
    printf(" - Lowest Debt-to-Equity\n");
    printf(" - Highest Dividend Yield\n");
    printf(" - Highest Promoter Holding\n");
}

//  analysis function to find and display top 3 companies out of the given  
void analyzeAndShowTop3(struct Company companies[], int n) {
    // Initialize with zeros
    int points[n][PARAM_COUNT];
    memset(points, 0, sizeof(points));

    // First assigning that the first company has the best value for each parameter highest or lowest respectively
    double max_revenue = companies[0].revenue;
    double min_pe = companies[0].pe_ratio;
    double max_profit = companies[0].net_profit;
    double max_marketcap = companies[0].market_cap;
    double min_debt = companies[0].debt_to_equity;
    double max_dividend = companies[0].dividend_yield;
    double max_promoter = companies[0].promoter_holding;
    
    // Find best values for each parameter
    for (int i = 1; i < n; i++) {
        if (companies[i].revenue > max_revenue) max_revenue = companies[i].revenue;// using simple bubble sort logic for finding the company with the best ratio
        if (companies[i].pe_ratio < min_pe) min_pe = companies[i].pe_ratio;
        if (companies[i].net_profit > max_profit) max_profit = companies[i].net_profit;
        if (companies[i].market_cap > max_marketcap) max_marketcap = companies[i].market_cap;
        if (companies[i].debt_to_equity < min_debt) min_debt = companies[i].debt_to_equity;
        if (companies[i].dividend_yield > max_dividend) max_dividend = companies[i].dividend_yield;
        if (companies[i].promoter_holding > max_promoter) max_promoter = companies[i].promoter_holding;
    }// after this sort now each of the parameters highest or lowest company is assigned properly 

    // now that all the parameters are designated properly then the companies are receiving one point each for being the highest or the lowest in each parameter 
    for (int i = 0; i < n; i++) {
        if (companies[i].revenue == max_revenue) points[i][0] = 1;//if so and so company has the respective highest or lowest value then that company's row in the 2d array and that 
        if (companies[i].pe_ratio == min_pe) points[i][1] = 1;//at that specific parameter column is given one point
        if (companies[i].net_profit == max_profit) points[i][2] = 1;
        if (companies[i].market_cap == max_marketcap) points[i][3] = 1;
        if (companies[i].debt_to_equity == min_debt) points[i][4] = 1;
        if (companies[i].dividend_yield == max_dividend) points[i][5] = 1;
        if (companies[i].promoter_holding == max_promoter) points[i][6] = 1;
    }

    // Display scoring criteria
    printScoringCriteria();//displaying scoring criteria
    // Display points table
    printPointsTable(companies, n, points);

    // Calculate total points for each company
    int total[n];
    for (int i = 0; i < n; i++) {
        total[i] = 0;
        for (int p = 0; p < PARAM_COUNT; p++) total[i] += points[i][p];//adding all the points in a specific row and total of all parameters is displayed

    }

    // Find top 3 companies based on total points
    int top[3] = {-1, -1, -1};
    for (int k = 0; k < 3; k++) {
        int max_score = -1, idx = -1;
        for (int i = 0; i < n; i++) {
            int already_selected = 0;
            // Check if company already in top 3
            for (int j = 0; j < k; j++) {
                if (top[j] == i) already_selected = 1;
            }
            // Update max score if current company has higher score
            if (!already_selected && total[i] > max_score) {
                max_score = total[i]; 
                idx = i;
            }
        }
        top[k] = idx;
    }

    // Display results for top 3 companies
    printf("\nTop 3 Companies (based on multi-parameter analysis):\n");
    int top_scores[3] = {0, 0, 0};
    int sum_top_scores = 0;
    // Calculate total scores for top 3
    for (int k = 0; k < 3; k++) {
        if (top[k] == -1) continue;
        int i = top[k];
        top_scores[k] = total[i];
        sum_top_scores += total[i];
    }
    // Print detailed information for each top company
    for (int k = 0; k < 3; k++) {
        if (top[k] == -1) continue;
        int i = top[k];
        printf("%d. %s (Score: %d)\n", k+1, companies[i].name, total[i]);
        printf("   Reasons: ");
        int first = 1;
        // Print reasons why company scored points
        if (points[i][0]) { printf("%sHighest Revenue", first ? "" : ", "); first = 0; } // 
        if (points[i][1]) { printf("%sLowest P/E Ratio", first ? "" : ", "); first = 0; }
        if (points[i][2]) { printf("%sHighest Net Profit", first ? "" : ", "); first = 0; }
        if (points[i][3]) { printf("%sHighest Market Cap", first ? "" : ", "); first = 0; }
        if (points[i][4]) { printf("%sLowest Debt-to-Equity", first ? "" : ", "); first = 0; }
        if (points[i][5]) { printf("%sHighest Dividend Yield", first ? "" : ", "); first = 0; }
        if (points[i][6]) { printf("%sHighest Promoter Holding", first ? "" : ", "); first = 0; }
        printf(".\n");
    }

    // Calculate and display investment percentage recommendations
    printf("\nInvestment Guidance (based on scores):\n");
    for (int k = 0; k < 3; k++) {
        if (top[k] == -1) continue;
        int i = top[k];
        // Calculate investment percentage based on relative scores
        double percent = (sum_top_scores > 0) ? (100.0 * total[i] / sum_top_scores) : 0.0;
        printf(" - %s: %.1f%% of your investment\n", companies[i].name, percent);
    }
}

// Main function - program entry point
int main() {
    int n = 0;  // Counter for number of companies
    struct Company companies[MAX_COMPANIES];  // Array to store company data
    // Open companies.txt file for reading
    FILE *fp = fopen("./companies.txt", "r");
    if (!fp) {
        printf("Error: Could not open companies.txt for reading.\n");
        return 1;
    }

    // Read company data from file
    while (n < MAX_COMPANIES && fscanf(fp, "%s %lf %lf %lf %lf %lf %lf %lf",//lf 
        companies[n].name,
        &companies[n].revenue,
        &companies[n].pe_ratio,
        &companies[n].net_profit,
        &companies[n].market_cap,
        &companies[n].debt_to_equity,
        &companies[n].dividend_yield,
        &companies[n].promoter_holding) == 8) {// fscanf is used to read data from the file 
        n++;
    }
    fclose(fp);  // Close file

    // Check if any data was read
    if (n == 0) {
        printf("No company data found in file.\n");
        return 1;
    }

    // Display company data and analysis
    printTable(companies, n);
    analyzeAndShowTop3(companies, n);

    return 0;
}