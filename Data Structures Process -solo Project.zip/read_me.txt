1) Open Windows power shell

2) CD to the folder containing the files
> cd path\to\folder

3) Compile the file 
> gcc company_comparison.c -o company_comparison

4) Run the program
> ./company_comparison.exe

5) Input File Format (companies.txt)-the sample data file is provided in the same folder as the program
The program reads from companies.txt which should be in the same folder.
Each line should contain company data in the following format:
CompanyName Revenue PE_Ratio NetProfit MarketCap DebtEquity DividendYield PromoterHolding

Eg. data:
Reliance 792756 24.5 67320 1920000 0.6 0.3 49.1
TCS 225458 30.2 44500 1340000 0.1 1.5 72.3

6) Eg. Output - the output should be like
Company         Revenue     P/E       Net Profit  Market Cap    Debt/Equity  DividendYield  PromoterHolding
---------------------------------------------------------------------------------------------------------------
Reliance       792756.00   24.50    67320.00    1920000.00    0.60         0.30           49.10
TCS            225458.00   30.20    44500.00    1340000.00    0.10         1.50           72.30

7) Eg output  - Analysis Criteria
Scoring Criteria -showing you that if a company has any of these properties it will be awarded 1 point.
 - Highest Revenue
 - Lowest P/E Ratio
 - Highest Net Profit
 - Highest Market Cap
 - Lowest Debt-to-Equity
 - Highest Dividend Yield
 - Highest Promoter Holding

8) Eg Output - Final Analysis Results
Top 3 Companies (based on multi-parameter analysis):
1. TCS (Score: 3)
   Reasons: Lowest Debt-to-Equity, Highest Dividend Yield, Highest Promoter Holding

2. Reliance (Score: 2)
   Reasons: Highest Revenue, Highest Market Cap

Investment Guidance (based on scores):
 - TCS: 60.0% of your investment
 - Reliance: 40.0% of your investment