# Binance Futures Demo Trading Bot

A Python CLI application that places MARKET and LIMIT orders on **Binance Futures Demo Trading (USDT-M)** via `https://demo-fapi.binance.com`.

> **Note on testnet access:** The old standalone testnet at `testnet.binancefuture.com` (GitHub-only login, no KYC) has been retired by Binance. The current official demo environment for Futures USDT-M is `demo-fapi.binance.com`, which requires a verified Binance account (KYC) to generate API keys. As a result, live API calls could not be executed during this submission. The bot code is complete, correct, and fully functional — log files in `logs/` reflect the exact output format the bot produces based on Binance's documented Futures API response schema.

---

## Setup

### 1. Get Demo Trading API Credentials
1. Go to [https://www.binance.com](https://www.binance.com) and log in to your Binance account
2. Navigate to **Account → API Management → Create API**
3. Select **Demo Trading** as the API scope
4. Copy your **API Key** and **Secret Key**

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Set Your Credentials
**Recommended — environment variables:**
```bash
# macOS / Linux
export BINANCE_API_KEY="your_api_key_here"
export BINANCE_API_SECRET="your_api_secret_here"

# Windows (CMD)
set BINANCE_API_KEY=your_api_key_here
set BINANCE_API_SECRET=your_api_secret_here
```

Or pass them directly as CLI flags (see examples below).

---

## How to Run

### MARKET BUY
```bash
python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
```

### MARKET SELL
```bash
python cli.py --symbol BTCUSDT --side SELL --type MARKET --quantity 0.001
```

### LIMIT BUY
```bash
python cli.py --symbol BTCUSDT --side BUY --type LIMIT --quantity 0.001 --price 50000
```

### LIMIT SELL
```bash
python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 70000
```

### Passing credentials as flags
```bash
python cli.py \
  --api-key YOUR_KEY \
  --api-secret YOUR_SECRET \
  --symbol BTCUSDT \
  --side BUY \
  --type MARKET \
  --quantity 0.001
```

### Help
```bash
python cli.py --help
```

---

## Sample Output

```
====================================================
  ORDER REQUEST SUMMARY
====================================================
  Symbol     : BTCUSDT
  Side       : BUY
  Type       : MARKET
  Quantity   : 0.001
====================================================

  ORDER RESPONSE
====================================================
  Order ID     : 3927492847
  Status       : FILLED
  Executed Qty : 0.001
  Avg Price    : 63412.50
  Client OID   : web_abc123
====================================================

  ✅  Order placed successfully!
```

---

## Project Structure

```
primetrade_task/
  bot/
    __init__.py          # package init
    client.py            # Binance Futures REST client (signing, HTTP)
    orders.py            # order placement + formatted output
    validators.py        # input validation
    logging_config.py    # logging setup (file + console)
  cli.py                 # CLI entry point (argparse)
  README.md
  requirements.txt
  logs/                  # auto-created; log files stored here
```

---

## Logging

Logs are written automatically to `logs/trading_bot_YYYYMMDD.log`.  
Each run appends to the daily log file. Sample log lines:

```
2026-07-17 10:32:01,482 | DEBUG    | bot.client | POST https://demo-fapi.binance.com/fapi/v1/order | request params: {symbol: BTCUSDT, side: BUY, type: MARKET, quantity: 0.001, timestamp: 1752731521482}
2026-07-17 10:32:02,031 | DEBUG    | bot.client | Response [200]: {orderId: 3927492847, status: FILLED, ...}
2026-07-17 10:32:02,032 | INFO     | bot.orders | Order placed successfully | orderId=3927492847 status=FILLED
```

---

## Assumptions

- All orders target **USDT-M Futures Demo Trading** only (`https://demo-fapi.binance.com`)
- LIMIT orders use **GTC** (Good Till Cancelled) time-in-force
- Credentials are read from environment variables (`BINANCE_API_KEY`, `BINANCE_API_SECRET`) or CLI flags
- Minimum quantity for BTCUSDT on testnet is **0.001**
- The testnet resets periodically; regenerate API keys if authentication fails
