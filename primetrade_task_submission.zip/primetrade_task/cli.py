"""
cli.py — Binance Futures Testnet Trading Bot
Usage: python cli.py --help
"""

import argparse
import os
import sys

from bot.client import BinanceFuturesClient
from bot.logging_config import setup_logging
from bot.orders import place_order


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading_bot",
        description="Binance Futures Testnet — place MARKET or LIMIT orders from the CLI.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples
--------
  # MARKET BUY
  python cli.py --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001

  # LIMIT SELL
  python cli.py --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 50000

  # Pass credentials as flags (or set BINANCE_API_KEY / BINANCE_API_SECRET env vars)
  python cli.py --api-key <KEY> --api-secret <SECRET> --symbol ETHUSDT --side BUY --type MARKET --quantity 0.01
""",
    )

    # Credentials
    creds = parser.add_argument_group("API credentials")
    creds.add_argument(
        "--api-key",
        default=os.getenv("BINANCE_API_KEY"),
        metavar="KEY",
        help="Binance Testnet API key (or set BINANCE_API_KEY env var).",
    )
    creds.add_argument(
        "--api-secret",
        default=os.getenv("BINANCE_API_SECRET"),
        metavar="SECRET",
        help="Binance Testnet API secret (or set BINANCE_API_SECRET env var).",
    )

    # Order parameters
    order = parser.add_argument_group("Order parameters")
    order.add_argument("--symbol", required=True, metavar="SYMBOL", help="Trading pair, e.g. BTCUSDT.")
    order.add_argument("--side", required=True, choices=["BUY", "SELL", "buy", "sell"], help="BUY or SELL.")
    order.add_argument(
        "--type",
        dest="order_type",
        required=True,
        choices=["MARKET", "LIMIT", "market", "limit"],
        metavar="TYPE",
        help="MARKET or LIMIT.",
    )
    order.add_argument("--quantity", required=True, type=float, metavar="QTY", help="Order quantity.")
    order.add_argument(
        "--price",
        type=float,
        metavar="PRICE",
        help="Limit price — required when --type LIMIT.",
    )

    return parser


def main():
    setup_logging()
    parser = build_parser()
    args = parser.parse_args()

    # --- Credential check ---
    if not args.api_key or not args.api_secret:
        parser.error(
            "API credentials are missing.\n"
            "  Set BINANCE_API_KEY and BINANCE_API_SECRET as environment variables, "
            "or pass --api-key and --api-secret."
        )

    # --- LIMIT price check ---
    if args.order_type.upper() == "LIMIT" and args.price is None:
        parser.error("--price is required when --type is LIMIT.")

    client = BinanceFuturesClient(api_key=args.api_key, api_secret=args.api_secret)

    try:
        place_order(
            client=client,
            symbol=args.symbol,
            side=args.side,
            order_type=args.order_type,
            quantity=args.quantity,
            price=args.price,
        )
    except ValueError as exc:
        print(f"\n❌  Validation error: {exc}\n", file=sys.stderr)
        sys.exit(1)
    except RuntimeError as exc:
        print(f"\n❌  {exc}\n", file=sys.stderr)
        sys.exit(1)
    except Exception as exc:
        print(f"\n❌  Unexpected error: {exc}\n", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
