from .client import BinanceFuturesClient
from .logging_config import get_logger
from .validators import (
    validate_order_type,
    validate_price,
    validate_quantity,
    validate_side,
    validate_symbol,
)

logger = get_logger(__name__)

_SEP = "=" * 52


def _print_summary(symbol, side, order_type, quantity, price):
    print(f"\n{_SEP}")
    print("  ORDER REQUEST SUMMARY")
    print(_SEP)
    print(f"  Symbol     : {symbol}")
    print(f"  Side       : {side}")
    print(f"  Type       : {order_type}")
    print(f"  Quantity   : {quantity}")
    if price is not None:
        print(f"  Price      : {price}")
    print(_SEP)


def _print_response(resp: dict):
    print(f"\n  ORDER RESPONSE")
    print(_SEP)
    print(f"  Order ID     : {resp.get('orderId', 'N/A')}")
    print(f"  Status       : {resp.get('status', 'N/A')}")
    print(f"  Executed Qty : {resp.get('executedQty', 'N/A')}")
    print(f"  Avg Price    : {resp.get('avgPrice', 'N/A')}")
    print(f"  Client OID   : {resp.get('clientOrderId', 'N/A')}")
    print(_SEP)


def place_order(
    client: BinanceFuturesClient,
    symbol: str,
    side: str,
    order_type: str,
    quantity: float,
    price: float | None = None,
) -> dict:
    """Validate inputs, print summary, place the order, and return the response."""

    # --- Validate ---
    symbol = validate_symbol(symbol)
    side = validate_side(side)
    order_type = validate_order_type(order_type)
    quantity = validate_quantity(quantity)
    if order_type == "LIMIT":
        if price is None:
            raise ValueError("--price is required for LIMIT orders.")
        price = validate_price(price)

    _print_summary(symbol, side, order_type, quantity, price)

    # --- Place ---
    try:
        response = client.place_order(symbol, side, order_type, quantity, price)
        _print_response(response)
        print("\n  ✅  Order placed successfully!\n")
        logger.info("Order placed successfully | orderId=%s status=%s", response.get("orderId"), response.get("status"))
        return response

    except Exception as exc:
        print(f"\n  ❌  Order failed: {exc}\n")
        logger.error("Order failed: %s", exc)
        raise
